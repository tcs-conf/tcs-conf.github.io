#!/usr/bin/perl

my $source = 'template-index.html';
my $target = 'template-index-new.html';
my $input;
my $output;

open($input,  "<:encoding(UTF-8)", "$source")
    or die "Cannot open $source: $!\n";
open($output, ">:encoding(UTF-8)", "$target")
    or die "Cannot open $target: $!\n";

while (my $line = <$input>) {
    chomp $line;
    if ($line =~ /(<td class="confname"><a href=.*_blank">)([^<]+)(<br>\&nbsp\;){0,3}<\/a>/) {
        my $confname = $1;
        my $acronym1 = $2;
        $acronym1 =~ s/ //g;
        my $break    = $3;

        $line = <$input>;
        chomp $line;
        if ($line =~ /(<span class="tooltiptext">)([^<]+)(<\/span>)/) {
            my $acronym2 = $2;
            if ($acronym1 ne $acronym2) {
                die "Acronyms \"$acronym1\" and \"$acronym2\" do not correspond\n";
            }
            $line = <$input>;
            chomp $line;
            if (! ($line =~ /<\/td>/)) {
                die "No closing <\/td> for tooltip $acronym2\n";
            }
        } else {
            die "Confname $acronym1 not followed by tooltiptext\n";
        }
        print $output "\t  ", $confname, $acronym1, $break, "<\/a><\/td>", "\n";
    } else {
        print $output $line, "\n";
    }
}

close $input;
close $output;
system("sync");

print STDERR "$source rewritten to $target\n";
