#!/usr/bin/perl

if (scalar @ARGV < 1 || scalar @ARGV > 2) {
    die "+++ Usage: $0 <template-index.html> [<conf-find.txt>]\n";
}

my $input;
my $list = 'conf-list.txt';
open($input, '<:encoding(UTF-8)', $list)
    or die "*** Cannot open < $list: $!\n";

my %conferences;
while (my $line = <$input>) {
    chomp $line;
    my @line = split /=>/, $line;
    $conferences{$line[0]} = $line[1];
}

close $input;
open($input, '<:encoding(UTF-8)', $ARGV[0])
    or die "*** Cannot open < $ARGV[0]: $!\n";

while (my $line = <$input>) {
    chomp $line;
    if ($line =~ /<span class=\"tooltiptext\">([^<]+)</) {
	delete $conferences{$1};
    }
}
close $input;

my $output = "STDOUT";
if (scalar @ARGV == 2) {
    open($output, '>:encoding(UTF-8)', $ARGV[1])
	or die "*** Cannot open > $ARGV[1]: $!\n";
}

for my $c (sort keys %conferences) {
    print $output "$c $conferences{$c}\n";
}

if (scalar @ARGV == 2) {
    close $output;
    print STDERR "+++ not found conferences written on $ARGV[1]\n";
}
