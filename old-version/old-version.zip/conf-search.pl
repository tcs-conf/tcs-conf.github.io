#!/usr/bin/perl

die "+++ Usage: $0 <year> [<conf-find.txt>]\n" if (scalar @ARGV < 1 || scalar @ARGV > 2);

my $filename = 'conf-search.html';
open(my $fh_out, '>:encoding(UTF-8)', $filename)
    or die "*** Cannot open > $filename: $!\n";

my $whitespace = 0;
my $space = ' ';

print $fh_out $space x $whitespace, "<!DOCTYPE html>\n";
print $fh_out $space x $whitespace, "<html lang=\"en-us\">\n";
$whitespace += 2;
print $fh_out $space x $whitespace, "<head>\n";
$whitespace += 2;
print $fh_out $space x $whitespace,
    "<title>Search for Conferences in Theoretical Computer Science</title>\n";
print $fh_out $space x $whitespace,
    "<meta name=\"description\" content=\"Search for Conferences in Theoretical Computer Science\">\n";
print $fh_out $space x $whitespace,
    "<meta name=\"author\" content=\"Miki Hermann\">\n";
print $fh_out $space x $whitespace,
    "<meta charset=\"UTF-8\">\n";
print $fh_out $space x $whitespace,
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";


print $fh_out $space x $whitespace, "<style>\n";
$whitespace += 2;
print $fh_out $space x $whitespace, "body {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "background-color: white;\n";
print $fh_out $space x $whitespace, "font-size: 100%;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n\n";

print $fh_out $space x $whitespace, "#intern {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "background-color: #eaf3da;\n";
print $fh_out $space x $whitespace, "margin-left: auto;\n";
print $fh_out $space x $whitespace, "margin-right: auto;\n";
print $fh_out $space x $whitespace, "width: 90%;\n";
print $fh_out $space x $whitespace, "border: 1px dotted gray;\n";
print $fh_out $space x $whitespace, "padding: 10px 10px 10px 10px;\n";
print $fh_out $space x $whitespace, "font-weight: normal;\n";
print $fh_out $space x $whitespace, "font-size:100%;\n";
print $fh_out $space x $whitespace, "font-family: Verdana, Geneva, Arial Black, sans-serif;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "h1 {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "font-weight: bold;\n";
print $fh_out $space x $whitespace, "font-size: 2.25em;\n";
print $fh_out $space x $whitespace, "text-align: center;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "h2 {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "font-weight: bold;\n";
print $fh_out $space x $whitespace, "font-size: 1.6875em;\n";
print $fh_out $space x $whitespace, "text-align: center;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "h3 {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "font-weight: bold;\n";
print $fh_out $space x $whitespace, "font-size: 1.125em;\n";
print $fh_out $space x $whitespace, "text-align: center;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "h4 {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "font-weight: bold;\n";
print $fh_out $space x $whitespace, "font-size: 1.0em;\n";
print $fh_out $space x $whitespace, "text-align: center;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "ul.navlist {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "font: bold 1.125em Verdana, Geneva, Arial Black, sans-serif;\n";
print $fh_out $space x $whitespace, "text-align: center;\n";
print $fh_out $space x $whitespace, "width: 85%;\n";
print $fh_out $space x $whitespace, "margin-left:  auto;\n";
print $fh_out $space x $whitespace, "margin-right: auto;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "li.navlist {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "display: inline;\n";
print $fh_out $space x $whitespace, "list-style-type: none;\n";
print $fh_out $space x $whitespace, "padding-right: 0.255em;\n";
print $fh_out $space x $whitespace, "padding-left:  0.255em;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "b {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "color: red;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "hr {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "color: red;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "table {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "border-width: 0px;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "table.central {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "margin-left:auto;\n";
print $fh_out $space x $whitespace, "margin-right:auto;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "th {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "text-align: left;\n";
print $fh_out $space x $whitespace, "border-width: 2px;\n";
print $fh_out $space x $whitespace, "padding: 5px;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "td {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "text-align: left;\n";
print $fh_out $space x $whitespace, "border-width: 2px;\n";
print $fh_out $space x $whitespace, "padding: 5px;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "a:link {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "text-decoration: none;\n";
print $fh_out $space x $whitespace, "font-weight: bold;\n";
print $fh_out $space x $whitespace, "color: darkblue;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "a:visited {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "text-decoration: none;\n";
print $fh_out $space x $whitespace, "font-weight: bold;\n";
# print $fh_out $space x $whitespace, "color: purple;\n";
print $fh_out $space x $whitespace, "color: gray;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "a[href]:hover, a[href]:active {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "background-color: aqua;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";
print $fh_out $space x $whitespace, "p.central, div.central {\n";
$whitespace += 4;
print $fh_out $space x $whitespace, "text-align: center;\n";
$whitespace -= 4;
print $fh_out $space x $whitespace, "}\n";

$whitespace -= 2;
print $fh_out $space x $whitespace, "</style>\n";

$whitespace -= 2;
print $fh_out $space x $whitespace, "</head>\n\n";

print $fh_out $space x $whitespace, "<body>\n";
$whitespace += 2;
print $fh_out $space x $whitespace, "<div id=\"intern\">\n";
$whitespace += 2;
print $fh_out $space x $whitespace, "<h1>Search for Conferences in Theoretical Computer Science</h1>\n\n";


my $year_beg = shift @ARGV;
my @conferences = ();
my $fh_in = STDIN;
if (scalar @ARGV == 1) {
    open($fh_in, '<:encoding(UTF-8)', $ARGV[0]) or die "*** Cannot open < $ARGV[0]: $!\n";
}
while (my $conf = <$fh_in>) {
    chomp $conf;
    push @conferences, $conf;
}

my $csc = 'computer+science+conference';
# my $csc = 'conference';

for my $year ($year_beg, $year_beg+1) {
    print $fh_out $space x $whitespace, "<h2>$year</h2>\n\n";
    
    my $i = 0;
    print $fh_out $space x $whitespace, "<table class=\"central\">\n";
    $whitespace += 2;
    print $fh_out $space x $whitespace, "<tbody>\n";
    $whitespace += 2;
    for my $conf (@conferences) {
	if ($i % 10 == 0) {
	    print $fh_out $space x $whitespace, "<tr>\n";
	    $whitespace += 2;
	}
	my @conf = split / /, $conf;
	my $acronym = shift @conf;
	my $name = join '+', @conf;
	print $fh_out $space x $whitespace, "<td><a href=\"http://www.google.com/search?q=$acronym+$year+$name+$csc\"  target=\"_blank\">$acronym $year</a></td>\n";
	if ($i % 10 == 9) {
	    $whitespace -= 2;
	    print $fh_out $space x $whitespace, "</tr>\n";
	}
	$i++;
    }
    if ($i != 0 && $i % 10 != 0) {
	$whitespace -= 2;
	print $fh_out $space x $whitespace, "</tr>\n"
    }
    $whitespace -= 2;
    print $fh_out $space x $whitespace, "</tbody>\n";
    $whitespace -= 2;
    print $fh_out $space x $whitespace, "</table>\n\n";
}

$whitespace -= 2;
print $fh_out $space x $whitespace, "</div>\n";
$whitespace -= 2;
print $fh_out $space x $whitespace, "</body>\n";
$whitespace -= 2;
print $fh_out $space x $whitespace, "</html>\n";

close $fh_out;

print STDERR "+++ Webpage for searching conferences is conf-search.html\n";
print STDERR "+++ you need to upload that webpage\n";
# system("git commit $filename -m 'automatic commit from " . $0 . "'") == 0
#     or die "No commit possible on $filename: $!\n";
# system("git push") == 0 || die "Push of $filename failed: $!\n";
